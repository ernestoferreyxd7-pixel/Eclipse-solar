# ☀ Eclipse Solar — mod de Fabric para Minecraft 1.21.1 (solo cliente)

La luna se acerca al sol y lo tapa de verdad (con animación). Mientras se cierra:

- el cielo se va oscureciendo y las nubes y la niebla se apagan;
- justo antes de la totalidad aparece el **anillo de diamante** (resplandor + rayos);
- en la totalidad se ve la **corona solar**, protuberancias rosadas, un **brillo naranja/rosa/violeta de 360° en el horizonte**
  y un **cielo lleno de estrellas**, planetas, Vía Láctea y estrellas fugaces;
- después la luna se aleja y vuelve el día (con otro anillo de diamante).

No usa texturas ni recursos externos: todo se dibuja por código.
Es **solo de cliente**: lo puedes meter en tu carpeta `mods` y funciona en tu mundo o en cualquier servidor (cada jugador que lo tenga lo ve).

## Cuándo ocurre
- Un eclipse natural **cada 5 días de Minecraft** (días 1, 6, 11, …), de 7500 a 10500 ticks (dura 2 min 30 s reales).
- Para verlo ya mismo (en cualquier mundo): `/eclipse now` (o `/eclipse now 60` para que dure 60 segundos).
- `/eclipse stop` lo detiene · `/eclipse info` dice cuánto falta para el próximo.
- Si es de noche, usa `/time set day` (hace falta ser admin) para que el sol esté en el cielo.

Para cambiar la frecuencia, la hora o la duración, edita las constantes de arriba en
`src/main/java/com/solareclipse/EclipseTimeline.java` (`DAYS_BETWEEN`, `START_TICK`, `DURATION_TICKS`, `MOON_RATIO`).

## Cómo sacar el .jar (hay que compilarlo una vez)
Necesitas **Java 21**. Elige una forma:

**A) Sin instalar nada: GitHub (gratis)**
1. Crea un repositorio nuevo en github.com y sube **todo el contenido de esta carpeta** (incluida `.github`).
2. Entra en la pestaña **Actions** → «Compilar el mod» → cuando termine (≈3 min) baja el archivo `solar-eclipse-jar`.
   Dentro está `solar-eclipse-1.0.0.jar`.

**B) IntelliJ IDEA (Community, gratis)**
1. *Open* → elige esta carpeta → deja que Gradle importe.
2. Panel *Gradle* → `Tasks` → `build` → `build`.
3. El .jar queda en `build/libs/solar-eclipse-1.0.0.jar` (no uses el `-sources`).

**C) Terminal:** con Gradle 8.10 instalado, `gradle build` dentro de esta carpeta.

## Instalar
1. Instala [Fabric Loader](https://fabricmc.net/use/) para **1.21.1**.
2. Pon **Fabric API** (1.21.1) y `solar-eclipse-1.0.0.jar` en la carpeta `mods`.

## Si ya tienes un proyecto Fabric 1.21.1
Copia `src/` encima del tuyo (sustituye `fabric.mod.json`) y compila.

## Notas
- **No se ve con shaders** (Iris/Optifine con paquete de shaders): ellos reemplazan el cielo de vanilla.
- Si Gradle dice que alguna versión no existe, cámbiala en `gradle.properties` por la que aparece en https://fabricmc.net/develop
- Al ser un mod visual, no cambia mobs ni el juego: solo lo que ves en el cielo y la luz.

package com.solareclipse;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;

/** Funciones que usan los mixins para oscurecer el cielo, las nubes, la niebla y la luz. */
public final class EclipseEffects {

    private EclipseEffects() {
    }

    public static EclipseTimeline.State state(ClientWorld world, float partial) {
        return EclipseTimeline.compute(world.getTime(), world.getTimeOfDay(), partial);
    }

    /** Color del cielo: del azul de día al azul casi negro de la totalidad. */
    public static Vec3d skyColor(Vec3d c, ClientWorld world, float partial) {
        EclipseTimeline.State s = state(world, partial);
        if (!s.active || s.dark < 0.002F) {
            return c;
        }
        return mix(c, 0.010, 0.016, 0.052, s.dark * 0.97);
    }

    public static Vec3d cloudColor(Vec3d c, ClientWorld world, float partial) {
        EclipseTimeline.State s = state(world, partial);
        if (!s.active || s.dark < 0.002F) {
            return c;
        }
        return mix(c, 0.045, 0.040, 0.070, s.dark * 0.95);
    }

    public static Vec3d fogColor(Vec3d c, ClientWorld world) {
        EclipseTimeline.State s = state(world, 0.0F);
        if (!s.active || s.dark < 0.002F) {
            return c;
        }
        return mix(c, 0.020, 0.025, 0.070, s.dark * 0.95);
    }

    /** Luz del cielo que llega al mundo (el "lightmap"): baja a nivel de noche con luna llena. */
    public static float skyBrightness(ClientWorld world, float vanilla) {
        EclipseTimeline.State s = state(world, 0.0F);
        if (!s.active || s.dark < 0.002F) {
            return vanilla;
        }
        float target = Math.min(vanilla, 0.36F);
        return vanilla + (target - vanilla) * s.dark * 0.95F;
    }

    /** Escala del sol cuadrado de vanilla: 1 = normal, 0 = invisible (lo reemplaza el sol redondo). */
    public static float vanillaSunScale() {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null) {
            return 1.0F;
        }
        EclipseTimeline.State s = state(world, 0.0F);
        return s.active ? 1.0F - s.sunFade : 1.0F;
    }

    private static Vec3d mix(Vec3d c, double r, double g, double b, double k) {
        return new Vec3d(c.x + (r - c.x) * k, c.y + (g - c.y) * k, c.z + (b - c.z) * k);
    }
}

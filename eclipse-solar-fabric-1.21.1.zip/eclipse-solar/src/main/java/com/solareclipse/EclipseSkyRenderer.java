package com.solareclipse;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.client.render.DimensionEffects;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.Arrays;
import java.util.Random;

/**
 * Dibuja el eclipse encima del cielo de vanilla: sol redondo, halo, luna, corona,
 * anillo de diamante, brillo del horizonte, estrellas, planetas y estrellas fugaces.
 * Todo se genera con triángulos de colores (no hace falta ninguna textura).
 */
public final class EclipseSkyRenderer {

    private static final float Y = 100.0F;                               // distancia del plano del sol (como vanilla)
    private static final float SR = 11.0F;                               // radio del sol
    private static final float MR = SR * EclipseTimeline.MOON_RATIO;     // radio de la luna
    private static final float PI = (float) Math.PI;
    private static final float TAU = PI * 2.0F;

    private EclipseSkyRenderer() {
    }

    // ============================================================================
    //  Punto de entrada (lo llama WorldRendererMixin al final de renderSky)
    // ============================================================================
    public static void render(Matrix4f view, float tickDelta, Camera camera, boolean thickFog, Runnable fogCallback) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        if (world == null || thickFog) {
            return;
        }
        CameraSubmersionType sub = camera.getSubmersionType();
        if (sub == CameraSubmersionType.LAVA || sub == CameraSubmersionType.POWDER_SNOW) {
            return;
        }
        if (world.getDimensionEffects().getSkyType() != DimensionEffects.SkyType.NORMAL) {
            return;
        }
        EclipseTimeline.State s = EclipseEffects.state(world, tickDelta);
        if (!s.active) {
            return;
        }

        float rain = EclipseTimeline.clamp01(world.getRainGradient(tickDelta));
        float clear = 1.0F - rain;                                         // la lluvia tapa el sol
        float time = (world.getTime() + tickDelta) / 20.0F;                // segundos de juego

        // Mismo marco que usa vanilla para el sol: gira con el ángulo del cielo
        float skyAngle = world.getSkyAngle(tickDelta) * TAU;
        Matrix4f sky = new Matrix4f(view).rotateY(-PI / 2.0F).rotateX(skyAngle);

        // Posición de la luna en el plano del sol
        float dx = (float) Math.sin(s.tilt), dz = (float) Math.cos(s.tilt);   // dirección de la trayectoria
        float nx = (float) Math.cos(s.tilt), nz = -(float) Math.sin(s.tilt);  // perpendicular
        float mx = (dx * s.moonX + nx * s.moonY) * SR;
        float mz = (dz * s.moonX + nz * s.moonY) * SR;

        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        BackgroundRenderer.clearFog();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        Mesh tri = new Mesh(VertexFormat.DrawMode.TRIANGLES);
        Mesh quad = new Mesh(VertexFormat.DrawMode.QUADS);

        // ---------- capa 1 (aditiva): estrellas, horizonte, halo, sol y corona ----------
        additive();
        float starA = s.stars * (1.0F - 0.6F * rain);
        if (starA > 0.01F) {
            drawStars(quad, tri, sky, time, starA);
            drawPlanets(tri, sky, time, starA);
            drawMeteor(quad, view, time, starA);
        }
        float horizon = (float) Math.pow(s.dark, 3.0) * 0.75F * (1.0F - 0.5F * rain);
        if (horizon > 0.01F) {
            drawHorizon(quad, view, horizon, time);
        }
        float sunA = s.sunFade * clear;
        if (sunA > 0.003F) {
            radial(tri, sky, 0.0F, 0.0F, HALO_RAD, HALO_COL, 40, 0.0F, s.bloom * sunA);
            radial(tri, sky, 0.0F, 0.0F, SUN_RAD, SUN_COL, 48, 0.0F, sunA);
        }
        if (s.corona > 0.003F) {
            drawCorona(quad, sky, s, time, s.corona * clear * 0.9F);
        }
        tri.flush();
        quad.flush();

        // ---------- capa 2 (normal): la luna, un disco oscuro que tapa todo lo de atrás ----------
        RenderSystem.defaultBlendFunc();
        if (s.moonAlpha > 0.003F) {
            drawMoon(tri, sky, mx, mz, s.moonAlpha);
            tri.flush();
        }

        // ---------- capa 3 (aditiva): anillo de diamante, rayos y protuberancias ----------
        additive();
        drawDiamond(tri, sky, s, mx, mz, time, clear);
        tri.flush();

        // ---------- dejar el estado como lo espera vanilla ----------
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        fogCallback.run();
    }

    private static void additive() {
        RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE,
                GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO);
    }

    // ============================================================================
    //  Sol, halo y luna (dibujados sobre el plano del sol)
    // ============================================================================
    private static final float[] HALO_RAD = scaled(new float[]{0F, 1.0F, 1.7F, 2.8F, 4.5F, 7.0F}, SR);
    private static final float[][] HALO_COL = {
            {1.00F, 0.93F, 0.78F, 0.60F}, {1.00F, 0.90F, 0.70F, 0.38F}, {1.00F, 0.88F, 0.68F, 0.19F},
            {0.95F, 0.88F, 0.78F, 0.08F}, {0.85F, 0.88F, 1.00F, 0.025F}, {0.80F, 0.85F, 1.00F, 0.0F}};
    private static final float[] SUN_RAD = scaled(new float[]{0F, 0.55F, 0.92F, 1.0F, 1.13F}, SR);
    private static final float[][] SUN_COL = {
            {1.00F, 0.99F, 0.93F, 1.0F}, {1.00F, 0.96F, 0.82F, 1.0F}, {1.00F, 0.86F, 0.58F, 0.95F},
            {1.00F, 0.80F, 0.46F, 0.72F}, {1.00F, 0.74F, 0.38F, 0.0F}};

    private static final float[] MOON_RAD = {0F, 0.97F * MR, MR, 1.04F * MR};
    private static final float[][] MOON_COL = {
            {0.012F, 0.013F, 0.019F, 1.0F}, {0.004F, 0.004F, 0.008F, 1.0F}, {0.0F, 0.0F, 0.0F, 0.96F}, {0.0F, 0.0F, 0.0F, 0.0F}};
    private static final float[][] PATCHES = { // {distancia al centro, ángulo, radio} como fracción del radio lunar
            {0.38F, 0.4F, 0.30F}, {0.55F, 2.1F, 0.22F}, {0.30F, 3.6F, 0.26F},
            {0.62F, 4.7F, 0.18F}, {0.12F, 5.6F, 0.20F}, {0.70F, 1.2F, 0.14F}};
    private static final float[][] PATCH_COL = {
            {0.060F, 0.065F, 0.085F, 0.55F}, {0.060F, 0.065F, 0.085F, 0.25F}, {0.060F, 0.065F, 0.085F, 0.0F}};

    private static void drawMoon(Mesh t, Matrix4f m, float mx, float mz, float alpha) {
        radial(t, m, mx, mz, MOON_RAD, MOON_COL, 64, 0.0F, alpha);
        for (float[] p : PATCHES) {
            float px = mx + (float) Math.cos(p[1]) * p[0] * MR;
            float pz = mz + (float) Math.sin(p[1]) * p[0] * MR;
            float rr = p[2] * MR;
            radial(t, m, px, pz, new float[]{0F, rr * 0.55F, rr}, PATCH_COL, 16, 0.0F, alpha);
        }
    }

    // ============================================================================
    //  Anillo de diamante, rayos, anillo en el borde lunar y protuberancias
    // ============================================================================
    private static final float[] DIAMOND_RAD = scaled(new float[]{0F, 0.35F, 0.9F, 1.9F}, SR);
    private static final float[][] DIAMOND_COL = {
            {1.0F, 0.98F, 0.92F, 1.00F}, {1.0F, 0.95F, 0.85F, 0.55F}, {1.0F, 0.90F, 0.75F, 0.14F}, {1.0F, 0.88F, 0.70F, 0.0F}};
    private static final float[] RING_RAD = {MR * 0.99F, MR * 1.012F, MR + 0.16F * SR, MR + 0.42F * SR};
    private static final float[][] RING_COL = {
            {1.0F, 0.95F, 0.88F, 0.80F}, {1.0F, 0.95F, 0.88F, 0.80F}, {0.95F, 0.90F, 1.0F, 0.25F}, {0.85F, 0.85F, 1.0F, 0.0F}};
    private static final float[][] PROM_COL = {
            {1.0F, 0.30F, 0.42F, 0.90F}, {1.0F, 0.25F, 0.35F, 0.35F}, {1.0F, 0.20F, 0.30F, 0.0F}};
    private static final float[] PROM_ANGLE = {0.7F, 2.6F, 4.3F};

    private static void drawDiamond(Mesh t, Matrix4f m, EclipseTimeline.State s, float mx, float mz, float time, float clear) {
        float md = (float) Math.hypot(mx, mz);
        float dm = s.diamond * clear * s.sunFade;
        if (dm > 0.004F && md > 0.001F) {
            // punto del borde del sol más alejado de la luna: lo último que queda de luz
            float px = -mx / md * SR;
            float pz = -mz / md * SR;
            radial(t, m, px, pz, DIAMOND_RAD, DIAMOND_COL, 24, 0.0F, dm);
            for (int k = 0; k < 6; k++) {
                float ang = time * 0.22F + k * (PI / 3.0F) + 0.4F;
                float len = SR * (2.4F + 1.2F * (float) Math.sin(time * 1.7F + k * 2.1F)) * (0.6F + 0.4F * dm);
                float wd = SR * 0.07F;
                float ddx = (float) Math.cos(ang), ddz = (float) Math.sin(ang);
                // los rayos que apuntan hacia la luna se atenúan para no "rayar" su disco
                float toMoon = (ddx * (mx - px) + ddz * (mz - pz)) / Math.max(0.001F, (float) Math.hypot(mx - px, mz - pz));
                float ra = dm * (1.0F - EclipseTimeline.smooth(-0.2F, 0.55F, toMoon));
                float ox = -ddz, oz = ddx;
                float sx = px + ddx * len * 0.10F, sz = pz + ddz * len * 0.10F;
                t.v(m, px, Y, pz, 1.0F, 0.97F, 0.90F, ra);
                t.v(m, sx + ox * wd, Y, sz + oz * wd, 1.0F, 0.97F, 0.90F, ra * 0.45F);
                t.v(m, px + ddx * len, Y, pz + ddz * len, 1.0F, 0.95F, 0.85F, 0.0F);
                t.v(m, px, Y, pz, 1.0F, 0.97F, 0.90F, ra);
                t.v(m, px + ddx * len, Y, pz + ddz * len, 1.0F, 0.95F, 0.85F, 0.0F);
                t.v(m, sx - ox * wd, Y, sz - oz * wd, 1.0F, 0.97F, 0.90F, ra * 0.45F);
            }
        }
        // fino anillo luminoso pegado al borde de la luna
        float ringA = (0.55F * s.diamond + 0.22F * s.total) * clear * s.moonAlpha;
        if (ringA > 0.004F) {
            radial(t, m, mx, mz, RING_RAD, RING_COL, 72, 0.0F, ringA);
        }
        // protuberancias rosadas en el borde (solo en la totalidad)
        float pa = s.total * clear;
        if (pa > 0.35F) {
            for (int k = 0; k < PROM_ANGLE.length; k++) {
                float ang = PROM_ANGLE[k] + 0.05F * (float) Math.sin(time * 0.7F + k);
                float px = mx + (float) Math.cos(ang) * MR * 1.01F;
                float pz = mz + (float) Math.sin(ang) * MR * 1.01F;
                float size = SR * (0.16F + 0.04F * (float) Math.sin(time * 1.3F + k * 1.9F));
                radial(t, m, px, pz, new float[]{0F, size * 0.5F, size}, PROM_COL, 14, 0.0F, (pa - 0.35F) / 0.65F);
            }
        }
    }

    // ============================================================================
    //  Corona solar (solo se ve cuando la luna casi tapa el sol del todo)
    // ============================================================================
    private static final float[] CORONA_RHO = {1.00F, 1.12F, 1.30F, 1.58F, 1.95F, 2.50F, 3.25F, 4.20F, 5.30F, 6.60F};
    private static final float[][] CORONA_RGB = coronaRgb();

    private static float[][] coronaRgb() {
        float[][] out = new float[CORONA_RHO.length][3];
        for (int i = 0; i < CORONA_RHO.length; i++) {
            float t = EclipseTimeline.clamp01((CORONA_RHO[i] - 1.0F) / 4.0F);
            out[i][0] = mix(1.00F, 0.72F, t);
            out[i][1] = mix(0.97F, 0.82F, t);
            out[i][2] = mix(0.93F, 1.00F, t);
        }
        return out;
    }

    private static float coronaAlpha(float rho, float streamer, float strength) {
        float d = rho - 1.0F;
        float a = 0.95F * (float) Math.exp(-d * 1.05F) + streamer * 0.55F * (float) Math.exp(-d * 0.36F);
        float edge = 1.0F - EclipseTimeline.smooth(4.2F, 6.6F, rho); // se apaga en el borde exterior
        return a * edge * strength;
    }

    private static void drawCorona(Mesh q, Matrix4f m, EclipseTimeline.State s, float time, float strength) {
        final int seg = 144;
        float tilt = s.tilt + 0.35F;
        float[] st = new float[seg + 1];
        for (int i = 0; i < seg; i++) {
            float th = i * TAU / seg;
            // dos grandes serpentinas ecuatoriales + cinco rayos medianos + rayos finos que "respiran"
            float eq = (float) Math.pow(Math.abs(Math.cos(th - tilt)), 7.0);
            float mid = (float) Math.pow(0.5 + 0.5 * Math.sin(5.0F * th + 0.7F + time * 0.10F), 6.0);
            float fine = (float) Math.pow(0.5 + 0.5 * Math.sin(11.0F * th + 2.0F - time * 0.15F), 10.0);
            float flick = 0.92F + 0.08F * (float) Math.sin(time * 2.1F + th * 3.0F);
            st[i] = (0.16F + 1.40F * eq + 0.50F * mid + 0.22F * fine) * flick;
        }
        st[seg] = st[0];
        for (int i = 0; i < seg; i++) {
            float a0 = i * TAU / seg, a1 = (i + 1) * TAU / seg;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0);
            float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            for (int k = 0; k < CORONA_RHO.length - 1; k++) {
                float ra = CORONA_RHO[k] * SR, rb = CORONA_RHO[k + 1] * SR;
                float[] ca = CORONA_RGB[k], cb = CORONA_RGB[k + 1];
                float aa0 = coronaAlpha(CORONA_RHO[k], st[i], strength);
                float ab0 = coronaAlpha(CORONA_RHO[k + 1], st[i], strength);
                float ab1 = coronaAlpha(CORONA_RHO[k + 1], st[i + 1], strength);
                float aa1 = coronaAlpha(CORONA_RHO[k], st[i + 1], strength);
                q.v(m, c0 * ra, Y, s0 * ra, ca[0], ca[1], ca[2], aa0);
                q.v(m, c0 * rb, Y, s0 * rb, cb[0], cb[1], cb[2], ab0);
                q.v(m, c1 * rb, Y, s1 * rb, cb[0], cb[1], cb[2], ab1);
                q.v(m, c1 * ra, Y, s1 * ra, ca[0], ca[1], ca[2], aa1);
            }
        }
    }

    // ============================================================================
    //  Brillo naranja/rosa/violeta de 360° en el horizonte (como en un eclipse total real)
    // ============================================================================
    private static final float[] HORIZON_Y = {-8.0F, 3.0F, 16.0F, 34.0F, 58.0F};
    private static final float[] HORIZON_A = {1.0F, 0.90F, 0.45F, 0.16F, 0.0F};
    private static final float[] HC = new float[3];

    private static void horizonColor(float phi, float up) {
        float t = 0.5F + 0.5F * (float) Math.sin(2.0F * phi + 0.6F);
        float u = 0.5F + 0.5F * (float) Math.sin(3.0F * phi + 2.1F);
        float r = 1.0F;
        float g = 0.52F - 0.22F * t + 0.16F * u;
        float b = 0.16F + 0.34F * t;
        HC[0] = mix(r, 0.50F, up);
        HC[1] = mix(g, 0.28F, up);
        HC[2] = mix(b, 0.85F, up);
    }

    private static void drawHorizon(Mesh q, Matrix4f view, float strength, float time) {
        final int seg = 72;
        for (int i = 0; i < seg; i++) {
            float p0 = i * TAU / seg, p1 = (i + 1) * TAU / seg;
            float x0 = 100.0F * (float) Math.cos(p0), z0 = 100.0F * (float) Math.sin(p0);
            float x1 = 100.0F * (float) Math.cos(p1), z1 = 100.0F * (float) Math.sin(p1);
            float pulse = 0.93F + 0.07F * (float) Math.sin(time * 0.8F + p0 * 2.0F);
            for (int j = 0; j < HORIZON_Y.length - 1; j++) {
                float up0 = j / (float) (HORIZON_Y.length - 1), up1 = (j + 1) / (float) (HORIZON_Y.length - 1);
                float a0 = HORIZON_A[j] * strength * pulse, a1 = HORIZON_A[j + 1] * strength * pulse;
                horizonColor(p0, up0);
                float r00 = HC[0], g00 = HC[1], b00 = HC[2];
                horizonColor(p0, up1);
                float r01 = HC[0], g01 = HC[1], b01 = HC[2];
                horizonColor(p1, up1);
                float r11 = HC[0], g11 = HC[1], b11 = HC[2];
                horizonColor(p1, up0);
                float r10 = HC[0], g10 = HC[1], b10 = HC[2];
                q.v(view, x0, HORIZON_Y[j], z0, r00, g00, b00, a0);
                q.v(view, x0, HORIZON_Y[j + 1], z0, r01, g01, b01, a1);
                q.v(view, x1, HORIZON_Y[j + 1], z1, r11, g11, b11, a1);
                q.v(view, x1, HORIZON_Y[j], z1, r10, g10, b10, a0);
            }
        }
    }

    // ============================================================================
    //  Estrellas, planetas y estrella fugaz
    // ============================================================================
    private static void drawStars(Mesh q, Mesh t, Matrix4f m, float time, float alpha) {
        StarField f = StarField.INSTANCE;
        // resplandor difuso de la Vía Láctea (manchas grandes y muy tenues)
        for (int i = 0; i < StarField.NEBULA; i++) {
            starGlow(t, m, f.ncx[i], f.ncy[i], f.ncz[i], f.nux[i], f.nuy[i], f.nuz[i], f.nwx[i], f.nwy[i], f.nwz[i],
                    f.nrad[i], f.nr[i], f.ng[i], f.nb[i], f.na[i] * alpha);
        }
        for (int i = 0; i < StarField.COUNT; i++) {
            float tw = 0.72F + 0.28F * (float) Math.sin(time * f.speed[i] + f.phase[i]);
            float a = f.bright[i] * tw * alpha;
            if (a < 0.01F) {
                continue;
            }
            float sz = f.size[i];
            float ux = f.t1x[i] * sz, uy = f.t1y[i] * sz, uz = f.t1z[i] * sz;
            float wx = f.t2x[i] * sz, wy = f.t2y[i] * sz, wz = f.t2z[i] * sz;
            float cx = f.cx[i], cy = f.cy[i], cz = f.cz[i];
            float r = f.r[i], g = f.g[i], b = f.b[i];
            q.v(m, cx - ux - wx, cy - uy - wy, cz - uz - wz, r, g, b, a);
            q.v(m, cx + ux - wx, cy + uy - wy, cz + uz - wz, r, g, b, a);
            q.v(m, cx + ux + wx, cy + uy + wy, cz + uz + wz, r, g, b, a);
            q.v(m, cx - ux + wx, cy - uy + wy, cz - uz + wz, r, g, b, a);
            if (f.halo[i] > 0.0F) {
                starGlow(t, m, cx, cy, cz, f.t1x[i], f.t1y[i], f.t1z[i], f.t2x[i], f.t2y[i], f.t2z[i],
                        f.halo[i], r, g, b, a * 0.55F);
            }
        }
    }

    /** Resplandor suave alrededor de una estrella o planeta: ocho triángulos con degradado. */
    private static void starGlow(Mesh t, Matrix4f m, float cx, float cy, float cz,
                                 float ux, float uy, float uz, float wx, float wy, float wz,
                                 float radius, float r, float g, float b, float a) {
        for (int i = 0; i < 8; i++) {
            float a0 = i * TAU / 8.0F, a1 = (i + 1) * TAU / 8.0F;
            float c0 = (float) Math.cos(a0) * radius, s0 = (float) Math.sin(a0) * radius;
            float c1 = (float) Math.cos(a1) * radius, s1 = (float) Math.sin(a1) * radius;
            t.v(m, cx, cy, cz, r, g, b, a);
            t.v(m, cx + ux * c0 + wx * s0, cy + uy * c0 + wy * s0, cz + uz * c0 + wz * s0, r, g, b, 0.0F);
            t.v(m, cx + ux * c1 + wx * s1, cy + uy * c1 + wy * s1, cz + uz * c1 + wz * s1, r, g, b, 0.0F);
        }
    }

    // {x, y, z, radio del brillo, r, g, b, intensidad}  (direcciones en el marco del cielo; el sol está en +Y)
    private static final float[][] PLANETS = {
            {0.62F, 0.78F, -0.30F, 2.6F, 1.00F, 0.96F, 0.82F, 0.95F},   // tipo Venus
            {-0.55F, 0.70F, 0.45F, 2.0F, 1.00F, 0.92F, 0.78F, 0.80F},   // tipo Júpiter
            {0.30F, 0.55F, 0.78F, 1.5F, 1.00F, 0.62F, 0.42F, 0.70F}};   // tipo Marte

    private static void drawPlanets(Mesh t, Matrix4f m, float time, float alpha) {
        for (int i = 0; i < PLANETS.length; i++) {
            float[] p = PLANETS[i];
            float len = (float) Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]);
            float dx = p[0] / len, dy = p[1] / len, dz = p[2] / len;
            float ux = 0.0F, uy = 1.0F, uz = 0.0F;
            float tx = uy * dz - uz * dy, ty = uz * dx - ux * dz, tz = ux * dy - uy * dx;
            float tl = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
            tx /= tl;
            ty /= tl;
            tz /= tl;
            float wx = dy * tz - dz * ty, wy = dz * tx - dx * tz, wz = dx * ty - dy * tx;
            float tw = 0.9F + 0.1F * (float) Math.sin(time * 1.3F + i * 2.0F);
            float a = p[7] * tw * alpha;
            starGlow(t, m, dx * 100.0F, dy * 100.0F, dz * 100.0F, tx, ty, tz, wx, wy, wz, p[3], p[4], p[5], p[6], a);
            starGlow(t, m, dx * 100.0F, dy * 100.0F, dz * 100.0F, tx, ty, tz, wx, wy, wz, p[3] * 0.35F, 1.0F, 1.0F, 1.0F, a);
        }
    }

    /** Una estrella fugaz cada pocos segundos (en el marco del mundo, siempre sobre el horizonte). */
    private static void drawMeteor(Mesh q, Matrix4f view, float time, float alpha) {
        final float period = 5.2F;
        final float duration = 0.85F;
        int idx = (int) Math.floor(time / period);
        float local = time - idx * period;
        if (local > duration || alpha < 0.5F) {
            return;
        }
        float p = local / duration;
        Random rnd = new Random(idx * 7919L + 31L);
        float az = rnd.nextFloat() * TAU;
        float el = (35.0F + rnd.nextFloat() * 40.0F) * PI / 180.0F;
        float th = rnd.nextFloat() * TAU;
        float ax = (float) (Math.cos(el) * Math.cos(az)), ay = (float) Math.sin(el), az2 = (float) (Math.cos(el) * Math.sin(az));
        // base tangente a la esfera en la dirección inicial
        float e1x = az2, e1y = 0.0F, e1z = -ax;
        float el1 = (float) Math.sqrt(e1x * e1x + e1z * e1z);
        e1x /= el1;
        e1z /= el1;
        float e2x = ay * e1z - az2 * e1y, e2y = az2 * e1x - ax * e1z, e2z = ax * e1y - ay * e1x;
        float wdx = (float) Math.cos(th) * e1x + (float) Math.sin(th) * e2x;
        float wdy = (float) Math.cos(th) * e1y + (float) Math.sin(th) * e2y;
        float wdz = (float) Math.cos(th) * e1z + (float) Math.sin(th) * e2z;
        float head = p * 0.6F;
        float tail = Math.max(0.0F, head - 0.16F);
        float hx = ax + wdx * head, hy = ay + wdy * head, hz = az2 + wdz * head;
        float tx = ax + wdx * tail, ty = ay + wdy * tail, tz = az2 + wdz * tail;
        float hl = (float) Math.sqrt(hx * hx + hy * hy + hz * hz), tl = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
        hx = hx / hl * 100.0F;
        hy = hy / hl * 100.0F;
        hz = hz / hl * 100.0F;
        tx = tx / tl * 100.0F;
        ty = ty / tl * 100.0F;
        tz = tz / tl * 100.0F;
        // perpendicular para darle grosor
        float nx = ay * wdz - az2 * wdy, ny = az2 * wdx - ax * wdz, nz = ax * wdy - ay * wdx;
        float a = (float) Math.sin(p * PI) * alpha;
        q.v(view, tx - nx * 0.02F, ty - ny * 0.02F, tz - nz * 0.02F, 0.9F, 0.95F, 1.0F, 0.0F);
        q.v(view, hx - nx * 0.30F, hy - ny * 0.30F, hz - nz * 0.30F, 0.9F, 0.95F, 1.0F, a);
        q.v(view, hx + nx * 0.30F, hy + ny * 0.30F, hz + nz * 0.30F, 0.9F, 0.95F, 1.0F, a);
        q.v(view, tx + nx * 0.02F, ty + ny * 0.02F, tz + nz * 0.02F, 0.9F, 0.95F, 1.0F, 0.0F);
    }

    // ============================================================================
    //  Utilidades de dibujo
    // ============================================================================

    /**
     * Disco / anillo con degradado radial sobre el plano del sol.
     * rad[k] = radio del anillo k, c[k] = {r, g, b, a}. Si rad[0] == 0 el primer anillo es el centro.
     */
    private static void radial(Mesh t, Matrix4f m, float cx, float cz, float[] rad, float[][] c, int seg, float rot, float amul) {
        float step = TAU / seg;
        for (int i = 0; i < seg; i++) {
            float a0 = rot + i * step;
            float a1 = a0 + step;
            float co0 = (float) Math.cos(a0), si0 = (float) Math.sin(a0);
            float co1 = (float) Math.cos(a1), si1 = (float) Math.sin(a1);
            for (int k = 0; k < rad.length - 1; k++) {
                float r0 = rad[k], r1 = rad[k + 1];
                float[] p = c[k], q = c[k + 1];
                if (r0 <= 0.0F) {
                    t.v(m, cx, Y, cz, p[0], p[1], p[2], p[3] * amul);
                    t.v(m, cx + co0 * r1, Y, cz + si0 * r1, q[0], q[1], q[2], q[3] * amul);
                    t.v(m, cx + co1 * r1, Y, cz + si1 * r1, q[0], q[1], q[2], q[3] * amul);
                } else {
                    float x00 = cx + co0 * r0, z00 = cz + si0 * r0;
                    float x01 = cx + co1 * r0, z01 = cz + si1 * r0;
                    float x10 = cx + co0 * r1, z10 = cz + si0 * r1;
                    float x11 = cx + co1 * r1, z11 = cz + si1 * r1;
                    t.v(m, x00, Y, z00, p[0], p[1], p[2], p[3] * amul);
                    t.v(m, x10, Y, z10, q[0], q[1], q[2], q[3] * amul);
                    t.v(m, x11, Y, z11, q[0], q[1], q[2], q[3] * amul);
                    t.v(m, x00, Y, z00, p[0], p[1], p[2], p[3] * amul);
                    t.v(m, x11, Y, z11, q[0], q[1], q[2], q[3] * amul);
                    t.v(m, x01, Y, z01, p[0], p[1], p[2], p[3] * amul);
                }
            }
        }
    }

    private static float mix(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float[] scaled(float[] a, float k) {
        float[] out = new float[a.length];
        for (int i = 0; i < a.length; i++) {
            out[i] = a[i] * k;
        }
        return out;
    }

    /**
     * Acumula vértices en memoria y los envía a la GPU de una sola vez.
     * (Así puede haber varias mallas "abiertas" a la vez sin pelearse por el Tessellator.)
     */
    private static final class Mesh {
        private final VertexFormat.DrawMode mode;
        private float[] data = new float[7 * 8192];
        private int count;
        private final Vector3f tmp = new Vector3f();

        Mesh(VertexFormat.DrawMode mode) {
            this.mode = mode;
        }

        void v(Matrix4f m, float x, float y, float z, float r, float g, float b, float a) {
            m.transformPosition(x, y, z, tmp);
            int i = count * 7;
            if (i + 7 > data.length) {
                data = Arrays.copyOf(data, data.length * 2);
            }
            data[i] = tmp.x;
            data[i + 1] = tmp.y;
            data[i + 2] = tmp.z;
            data[i + 3] = EclipseTimeline.clamp01(r);
            data[i + 4] = EclipseTimeline.clamp01(g);
            data[i + 5] = EclipseTimeline.clamp01(b);
            data[i + 6] = EclipseTimeline.clamp01(a);
            count++;
        }

        void flush() {
            if (count == 0) {
                return;
            }
            BufferBuilder bb = Tessellator.getInstance().begin(mode, VertexFormats.POSITION_COLOR);
            for (int n = 0; n < count; n++) {
                int i = n * 7;
                bb.vertex(data[i], data[i + 1], data[i + 2]).color(data[i + 3], data[i + 4], data[i + 5], data[i + 6]);
            }
            BufferRenderer.drawWithGlobalProgram(bb.end());
            count = 0;
        }
    }
}

package com.solareclipse;

/**
 * Calcula en qué fase está el eclipse en cada instante.
 * No usa clases de Minecraft (así se puede probar aparte).
 * Las distancias geométricas se miden en "radios del sol" (el sol mide 1.0).
 */
public final class EclipseTimeline {

    // ======================= AJUSTES (edítalos si quieres) =======================
    /** Cada cuántos días de Minecraft hay un eclipse natural. */
    public static final int DAYS_BETWEEN = 5;
    /** En qué día del ciclo ocurre (0 .. DAYS_BETWEEN-1). Con 1: día 1, 6, 11... */
    public static final int DAY_PHASE = 1;
    /** Tick del día en que empieza (0 = amanecer, 6000 = mediodía, 12000 = atardecer). */
    public static final int START_TICK = 7500;
    /** Duración total en ticks (20 ticks = 1 segundo). 3000 = 2 min 30 s. */
    public static final int DURATION_TICKS = 3000;
    // =============================================================================

    /** Radio de la luna respecto al del sol (si es mayor que 1 hay totalidad). */
    public static final float MOON_RATIO = 1.22F;
    /** Distancia inicial de la luna al centro del sol (la luna "se acerca" desde fuera). */
    private static final float START_DISTANCE = 1.0F + MOON_RATIO + 1.6F;

    private static long forcedStart = -1L;
    private static int forcedDuration = DURATION_TICKS;
    private static int forcedSeed = 1;

    private EclipseTimeline() {
    }

    /** Todo lo que el renderizador y los efectos necesitan saber de un instante. */
    public static final class State {
        public boolean active;
        /** Progreso del eclipse, de 0 a 1. */
        public float u;
        /** Posición de la luna a lo largo de su trayectoria (radios solares; + = oeste). */
        public float moonX;
        /** Desplazamiento de la luna en perpendicular a la trayectoria. */
        public float moonY;
        /** Inclinación de la trayectoria (radianes). */
        public float tilt;
        /** Fracción del disco solar tapada (0..1). */
        public float cover;
        /** Fracción visible del sol (1 - cover). */
        public float visible;
        /** Oscuridad del cielo (0..1). */
        public float dark;
        /** 1 durante la totalidad. */
        public float total;
        /** Visibilidad de las estrellas (0..1). */
        public float stars;
        /** Intensidad de la corona (0..1). */
        public float corona;
        /** Intensidad del "anillo de diamante" (0..1). */
        public float diamond;
        /** Resplandor alrededor del sol (0..1). */
        public float bloom;
        /** 0 = sol cuadrado de vanilla, 1 = sol redondo del eclipse. */
        public float sunFade;
        /** Opacidad de la luna (aparece y desaparece suavemente). */
        public float moonAlpha;
    }

    // --------------------------- eclipse forzado (/eclipse now) ---------------------------

    public static void startForced(long worldTime, int ticks) {
        forcedStart = worldTime;
        forcedDuration = Math.max(200, ticks);
        forcedSeed = (int) (worldTime & 0x7FFFFFFFL);
    }

    public static void stopForced() {
        forcedStart = -1L;
    }

    public static boolean isForced() {
        return forcedStart >= 0L;
    }

    // ------------------------------------ cálculo ------------------------------------

    public static State compute(long worldTime, long timeOfDay, float partial) {
        State s = new State();
        float u;
        int seed;
        if (forcedStart >= 0L) {
            u = ((worldTime - forcedStart) + partial) / (float) forcedDuration;
            if (u < 0.0F || u >= 1.0F) {
                // terminó (o es otro mundo): vuelve al calendario natural
                forcedStart = -1L;
                return compute(worldTime, timeOfDay, partial);
            }
            seed = forcedSeed;
        } else {
            long day = Math.floorDiv(timeOfDay, 24000L);
            if (Math.floorMod(day, (long) DAYS_BETWEEN) != DAY_PHASE) {
                return s;
            }
            float tod = (float) Math.floorMod(timeOfDay, 24000L) + partial;
            u = (tod - START_TICK) / (float) DURATION_TICKS;
            seed = (int) (day * 7919L);
        }
        if (u < 0.0F || u > 1.0F) {
            return s;
        }

        // Cada eclipse tiene una trayectoria algo distinta
        float tilt = (hash(seed, 1) - 0.5F) * 0.9F;
        float offset = (hash(seed, 2) - 0.5F) * 0.20F;

        // La luna entra por el oeste, frena al pasar por el centro y sale por el este
        float v = 2.0F * u - 1.0F;
        float pos = -START_DISTANCE * (0.35F * v + 0.65F * v * v * v);
        float dist = (float) Math.hypot(pos, offset);
        float cover = overlap(dist);
        float vis = 1.0F - cover;

        s.active = true;
        s.u = u;
        s.moonX = pos;
        s.moonY = offset;
        s.tilt = tilt;
        s.cover = cover;
        s.visible = vis;
        s.dark = (float) Math.pow(smooth(0.30F, 1.0F, cover), 1.7);
        s.total = smooth(0.985F, 1.0F, cover);
        s.stars = smooth(0.55F, 0.92F, s.dark);
        s.corona = smooth(0.90F, 0.995F, cover);
        s.diamond = smooth(0.20F, 0.04F, vis) * smooth(0.0F, 0.004F, vis);
        s.bloom = clamp01(0.10F + 0.90F * (float) Math.pow(vis, 0.55) + 0.35F * s.diamond);
        s.sunFade = smooth(0.0F, 0.06F, u) * (1.0F - smooth(0.94F, 1.0F, u));
        s.moonAlpha = smooth(0.0F, 0.05F, u) * (1.0F - smooth(0.95F, 1.0F, u));
        return s;
    }

    /** Ticks que faltan para el próximo eclipse natural (0 si hay uno en curso). */
    public static long ticksUntilNext(long timeOfDay) {
        long day = Math.floorDiv(timeOfDay, 24000L);
        for (int i = 0; i <= DAYS_BETWEEN; i++) {
            long d = day + i;
            if (Math.floorMod(d, (long) DAYS_BETWEEN) == DAY_PHASE) {
                long start = d * 24000L + START_TICK;
                if (start + DURATION_TICKS > timeOfDay) {
                    return Math.max(0L, start - timeOfDay);
                }
            }
        }
        return -1L;
    }

    // ---------------------------------- matemáticas ----------------------------------

    /** Fracción del disco del sol (radio 1) tapada por la luna (radio MOON_RATIO) a distancia d. */
    static float overlap(float dist) {
        double r = 1.0;
        double rr = MOON_RATIO;
        double d = dist;
        if (d >= r + rr) {
            return 0.0F;
        }
        if (d <= rr - r) {
            return 1.0F;
        }
        double a = clampD((d * d + r * r - rr * rr) / (2.0 * d * r));
        double b = clampD((d * d + rr * rr - r * r) / (2.0 * d * rr));
        double k = (-d + r + rr) * (d + r - rr) * (d - r + rr) * (d + r + rr);
        double area = r * r * Math.acos(a) + rr * rr * Math.acos(b) - 0.5 * Math.sqrt(Math.max(0.0, k));
        return (float) (area / (Math.PI * r * r));
    }

    private static double clampD(double x) {
        return Math.max(-1.0, Math.min(1.0, x));
    }

    static float clamp01(float x) {
        return x < 0.0F ? 0.0F : (x > 1.0F ? 1.0F : x);
    }

    /** smoothstep; también funciona con los bordes al revés (a > b). */
    static float smooth(float a, float b, float x) {
        float t = clamp01((x - a) / (b - a));
        return t * t * (3.0F - 2.0F * t);
    }

    private static float hash(int seed, int salt) {
        int h = seed * 374761393 + salt * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= (h >>> 16);
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }
}

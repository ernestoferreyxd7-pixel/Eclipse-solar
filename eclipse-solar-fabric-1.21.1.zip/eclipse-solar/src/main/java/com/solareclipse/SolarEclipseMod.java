package com.solareclipse;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

/**
 * Mod de eclipse solar (solo cliente).
 * Comandos:  /eclipse now [segundos]   /eclipse stop   /eclipse info
 */
public class SolarEclipseMod implements ClientModInitializer {

    public static final String MOD_ID = "solar_eclipse";

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("eclipse")
                        .executes(ctx -> info(ctx.getSource()))
                        .then(ClientCommandManager.literal("now")
                                .executes(ctx -> start(ctx.getSource(), 150))
                                .then(ClientCommandManager.argument("segundos", IntegerArgumentType.integer(20, 900))
                                        .executes(ctx -> start(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "segundos")))))
                        .then(ClientCommandManager.literal("stop")
                                .executes(ctx -> stop(ctx.getSource())))
                        .then(ClientCommandManager.literal("info")
                                .executes(ctx -> info(ctx.getSource())))));
    }

    private static int start(FabricClientCommandSource source, int seconds) {
        ClientWorld world = source.getWorld();
        EclipseTimeline.startForced(world.getTime(), seconds * 20);
        source.sendFeedback(Text.literal("§6☀ Eclipse solar iniciado §7(" + seconds + " s). Mira al sol."));
        long tod = Math.floorMod(world.getTimeOfDay(), 24000L);
        if (tod > 12000L) {
            source.sendFeedback(Text.literal("§eAhora es de noche: espera al día (o usa /time set day) para ver al sol."));
        }
        return 1;
    }

    private static int stop(FabricClientCommandSource source) {
        EclipseTimeline.stopForced();
        source.sendFeedback(Text.literal("§7Eclipse forzado detenido."));
        return 1;
    }

    private static int info(FabricClientCommandSource source) {
        ClientWorld world = source.getWorld();
        long ticks = EclipseTimeline.ticksUntilNext(world.getTimeOfDay());
        source.sendFeedback(Text.literal("§6☀ Eclipse solar §7- un eclipse natural cada " + EclipseTimeline.DAYS_BETWEEN + " días."));
        if (ticks == 0L) {
            source.sendFeedback(Text.literal("§aHay un eclipse en curso ahora mismo."));
        } else if (ticks > 0L) {
            long seconds = ticks / 20L;
            source.sendFeedback(Text.literal("§7Próximo eclipse en §f" + (seconds / 60L) + " min " + (seconds % 60L) + " s §7(tiempo de juego)."));
        }
        source.sendFeedback(Text.literal("§7Usa §f/eclipse now [segundos]§7 para verlo ahora y §f/eclipse stop§7 para pararlo."));
        return 1;
    }
}

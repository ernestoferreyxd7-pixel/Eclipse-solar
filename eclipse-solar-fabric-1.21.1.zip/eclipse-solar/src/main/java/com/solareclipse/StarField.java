package com.solareclipse;

import java.util.Random;

/** Campo de estrellas fijo (se genera una sola vez): estrellas sueltas + una banda tipo Vía Láctea. */
final class StarField {

    static final int UNIFORM = 2300;           // estrellas repartidas por todo el cielo
    static final int BAND = 1500;              // estrellas concentradas en la Vía Láctea (más tenues)
    static final int COUNT = UNIFORM + BAND;
    static final int NEBULA = 44;              // manchas de resplandor a lo largo de la banda

    static final StarField INSTANCE = new StarField();

    // centro (ya multiplicado por 100) y tangentes unitarias
    final float[] cx = new float[COUNT], cy = new float[COUNT], cz = new float[COUNT];
    final float[] t1x = new float[COUNT], t1y = new float[COUNT], t1z = new float[COUNT];
    final float[] t2x = new float[COUNT], t2y = new float[COUNT], t2z = new float[COUNT];
    final float[] size = new float[COUNT];
    final float[] r = new float[COUNT], g = new float[COUNT], b = new float[COUNT];
    final float[] bright = new float[COUNT];
    final float[] phase = new float[COUNT], speed = new float[COUNT];
    /** > 0 en las estrellas más brillantes: radio del halo suave. */
    final float[] halo = new float[COUNT];

    // manchas de la Vía Láctea
    final float[] ncx = new float[NEBULA], ncy = new float[NEBULA], ncz = new float[NEBULA];
    final float[] nux = new float[NEBULA], nuy = new float[NEBULA], nuz = new float[NEBULA];
    final float[] nwx = new float[NEBULA], nwy = new float[NEBULA], nwz = new float[NEBULA];
    final float[] nrad = new float[NEBULA], nr = new float[NEBULA], ng = new float[NEBULA], nb = new float[NEBULA], na = new float[NEBULA];

    private final double[] tan = new double[6];

    private StarField() {
        Random rnd = new Random(20260609L);

        // eje y base de la banda de la Vía Láctea
        double ax = 0.52, ay = 0.66, az = 0.54;
        double al = Math.sqrt(ax * ax + ay * ay + az * az);
        ax /= al;
        ay /= al;
        az /= al;
        double e1x = az, e1y = 0.0, e1z = -ax;
        double el = Math.sqrt(e1x * e1x + e1z * e1z);
        e1x /= el;
        e1z /= el;
        double e2x = ay * e1z - az * e1y;
        double e2y = az * e1x - ax * e1z;
        double e2z = ax * e1y - ay * e1x;

        for (int i = 0; i < COUNT; i++) {
            double dx, dy, dz;
            float br;
            if (i < UNIFORM) {
                // distribución uniforme en la esfera
                double y = rnd.nextDouble() * 2.0 - 1.0;
                double phi = rnd.nextDouble() * Math.PI * 2.0;
                double rr = Math.sqrt(1.0 - y * y);
                dx = rr * Math.cos(phi);
                dy = y;
                dz = rr * Math.sin(phi);
                br = 0.36F + 0.64F * (float) Math.pow(rnd.nextDouble(), 3.0);
            } else {
                // estrellas concentradas cerca de un círculo máximo
                double phi = rnd.nextDouble() * Math.PI * 2.0;
                double lat = rnd.nextGaussian() * 0.12;
                double cl = Math.cos(lat), sl = Math.sin(lat);
                double px = Math.cos(phi), pz = Math.sin(phi);
                dx = cl * (px * e1x + pz * e2x) + sl * ax;
                dy = cl * (px * e1y + pz * e2y) + sl * ay;
                dz = cl * (px * e1z + pz * e2z) + sl * az;
                br = 0.20F + 0.50F * (float) Math.pow(rnd.nextDouble(), 2.5);
            }
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            dx /= len;
            dy /= len;
            dz /= len;
            basis(dx, dy, dz, rnd.nextDouble() * Math.PI);

            cx[i] = (float) (dx * 100.0);
            cy[i] = (float) (dy * 100.0);
            cz[i] = (float) (dz * 100.0);
            t1x[i] = (float) tan[0];
            t1y[i] = (float) tan[1];
            t1z[i] = (float) tan[2];
            t2x[i] = (float) tan[3];
            t2y[i] = (float) tan[4];
            t2z[i] = (float) tan[5];
            bright[i] = br;
            size[i] = 0.11F + 0.20F * br;

            float temp = rnd.nextFloat();
            if (temp < 0.55F) {
                r[i] = 1.0F; g[i] = 1.0F; b[i] = 1.0F;
            } else if (temp < 0.78F) {
                r[i] = 0.78F; g[i] = 0.87F; b[i] = 1.0F;
            } else if (temp < 0.92F) {
                r[i] = 1.0F; g[i] = 0.93F; b[i] = 0.76F;
            } else {
                r[i] = 1.0F; g[i] = 0.78F; b[i] = 0.60F;
            }
            phase[i] = rnd.nextFloat() * 6.2831855F;
            speed[i] = 0.8F + rnd.nextFloat() * 2.6F;
            halo[i] = (i < UNIFORM && br > 0.86F) ? size[i] * 7.0F : 0.0F;
        }

        // manchas suaves de la Vía Láctea
        for (int i = 0; i < NEBULA; i++) {
            double phi = rnd.nextDouble() * Math.PI * 2.0;
            double lat = rnd.nextGaussian() * 0.09;
            double cl = Math.cos(lat), sl = Math.sin(lat);
            double px = Math.cos(phi), pz = Math.sin(phi);
            double dx = cl * (px * e1x + pz * e2x) + sl * ax;
            double dy = cl * (px * e1y + pz * e2y) + sl * ay;
            double dz = cl * (px * e1z + pz * e2z) + sl * az;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            dx /= len;
            dy /= len;
            dz /= len;
            basis(dx, dy, dz, 0.0);
            ncx[i] = (float) (dx * 100.0);
            ncy[i] = (float) (dy * 100.0);
            ncz[i] = (float) (dz * 100.0);
            nux[i] = (float) tan[0];
            nuy[i] = (float) tan[1];
            nuz[i] = (float) tan[2];
            nwx[i] = (float) tan[3];
            nwy[i] = (float) tan[4];
            nwz[i] = (float) tan[5];
            nrad[i] = 7.0F + rnd.nextFloat() * 10.0F;
            float k = rnd.nextFloat();
            if (k < 0.5F) {
                nr[i] = 0.45F; ng[i] = 0.55F; nb[i] = 1.0F;      // azulada
            } else if (k < 0.8F) {
                nr[i] = 0.75F; ng[i] = 0.50F; nb[i] = 1.0F;      // violeta
            } else {
                nr[i] = 1.0F; ng[i] = 0.78F; nb[i] = 0.62F;      // cálida
            }
            na[i] = 0.05F + rnd.nextFloat() * 0.06F;
        }
    }

    /** Calcula dos tangentes unitarias perpendiculares a (dx,dy,dz), giradas "rot" radianes. Resultado en tan[]. */
    private void basis(double dx, double dy, double dz, double rot) {
        double ux = 0.0, uy = 1.0, uz = 0.0;
        if (Math.abs(dy) > 0.98) {
            ux = 1.0;
            uy = 0.0;
        }
        double tx = uy * dz - uz * dy, ty = uz * dx - ux * dz, tz = ux * dy - uy * dx;
        double tl = Math.sqrt(tx * tx + ty * ty + tz * tz);
        tx /= tl;
        ty /= tl;
        tz /= tl;
        double wx = dy * tz - dz * ty, wy = dz * tx - dx * tz, wz = dx * ty - dy * tx;
        double cr = Math.cos(rot), sr = Math.sin(rot);
        tan[0] = tx * cr + wx * sr;
        tan[1] = ty * cr + wy * sr;
        tan[2] = tz * cr + wz * sr;
        tan[3] = -tx * sr + wx * cr;
        tan[4] = -ty * sr + wy * cr;
        tan[5] = -tz * sr + wz * cr;
    }
}

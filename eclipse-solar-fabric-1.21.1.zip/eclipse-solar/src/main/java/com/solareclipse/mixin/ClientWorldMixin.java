package com.solareclipse.mixin;

import com.solareclipse.EclipseEffects;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {

    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void solarEclipse$skyColor(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        cir.setReturnValue(EclipseEffects.skyColor(cir.getReturnValue(), (ClientWorld) (Object) this, tickDelta));
    }

    @Inject(method = "getCloudsColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void solarEclipse$cloudsColor(float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        cir.setReturnValue(EclipseEffects.cloudColor(cir.getReturnValue(), (ClientWorld) (Object) this, tickDelta));
    }
}

package com.solareclipse.mixin;

import com.solareclipse.EclipseEffects;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LightmapTextureManager.class)
public abstract class LightmapTextureManagerMixin {

    /** Baja la luz del cielo que recibe el mundo mientras dura la oscuridad del eclipse. */
    @Redirect(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/world/ClientWorld;getSkyBrightness(F)F"),
            require = 0)
    private float solarEclipse$skyBrightness(ClientWorld world, float delta) {
        return EclipseEffects.skyBrightness(world, world.getSkyBrightness(delta));
    }
}

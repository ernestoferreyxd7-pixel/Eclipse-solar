package com.solareclipse.mixin;

import com.solareclipse.EclipseEffects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.DimensionEffects;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DimensionEffects.Overworld.class)
public abstract class OverworldEffectsMixin {

    /** Oscurece la niebla del horizonte durante el eclipse. */
    @Inject(method = "adjustFogColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void solarEclipse$fogColor(Vec3d color, float sunHeight, CallbackInfoReturnable<Vec3d> cir) {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world != null) {
            cir.setReturnValue(EclipseEffects.fogColor(cir.getReturnValue(), world));
        }
    }
}

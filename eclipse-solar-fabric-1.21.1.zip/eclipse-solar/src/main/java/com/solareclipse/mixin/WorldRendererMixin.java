package com.solareclipse.mixin;

import com.solareclipse.EclipseEffects;
import com.solareclipse.EclipseSkyRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.WorldRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {

    /** El sol cuadrado de vanilla (30.0 de tamaño) se encoge mientras aparece el sol redondo del eclipse. */
    @ModifyConstant(method = "renderSky", constant = @Constant(floatValue = 30.0F), require = 0)
    private float solarEclipse$sunSize(float original) {
        return original * EclipseEffects.vanillaSunScale();
    }

    /** Dibuja el eclipse al final de renderSky (después del cielo de vanilla). */
    @Inject(method = "renderSky", at = @At("TAIL"))
    private void solarEclipse$renderSky(Matrix4f matrix4f, Matrix4f projectionMatrix, float tickDelta, Camera camera,
                                        boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        EclipseSkyRenderer.render(matrix4f, tickDelta, camera, thickFog, fogCallback);
    }
}
